### Grupo 21 ###
- João Santos 56380
- Rafael Ferreira 57544
- Ricardo Mateus 56366


Comandos make para:
	Gerar os targets libtable, table-client e table-server:
		make all
	Gerar biblioteca estática libtable:
		make libtable
	Eliminar os conteudos das diretorias object e binary e lib:
		make clean
	Compilar todo o código do cliente:
		make table-client
	Compilar todo o código do servidor:
		make table-server


### Observações ###
- Nos programas está a ser usado um short em vez de unsigned short, o que diminui a capacidade do servidor aguentar pedidos com buffers acima de 32,767 bytes.

- Para os testes realizados pelo grupo, o programa não aparenta ter memory leaks nem outros erros reportados pelo valgrind.

- É necessário que o ficheiro sdmessage.proto esteja no diretório 'grupo21' para a execução do comando 'make all', pois no enunciado não indicava se o ficheiro 'sdmessage.proto' podia estar no diretório ou não. Caso se decida remover o 'sdmessage.proto', para fazer com que o comando 'make all' funcione, 
basta apenas comentar as linhas 70, 71 e 72 do makefile, que são referentes à geração dos ficheiros 'sdmessage.pb-c.c' e 'sdmessage.pb-c.h' e à deslocação destes ficheiros para as suas respetivas
pastas (/source e /include).
