// Grupo 21
// Joao Santos 56380
// Rafael Ferreira 57544
// Ricardo Mateus 56366
#ifndef _ENTRY_PRIVATE_H
#define _ENTRY_PRIVATE_H

#include "entry.h"
/* Função que valida um entry.
 * Retorna 0 (OK) ou -1 em caso de erro.
 */
int entry_valid(struct entry_t*);

#endif
