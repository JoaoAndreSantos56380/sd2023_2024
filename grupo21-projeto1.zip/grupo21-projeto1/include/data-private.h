// Grupo 21
// Joao Santos 56380
// Rafael Ferreira 57544
// Ricardo Mateus 56366
#ifndef _DATA_PRIVATE_H
#define _DATA_PRIVATE_H

/* Função que valida um bloco de dados.
 * Retorna 0 (OK) ou -1 em caso de erro.
 */
int data_valid(struct data_t* data);

#endif
